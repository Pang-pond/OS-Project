#!/usr/bin/env bash
set -euo pipefail
cd /app
exec ./server
